$(function(){
  document.body.style.opacity = 1;

  // NAV
  var Navigation = { $element: $('.Navigation') };
  function onResize() {
    var wHeight = $(window).height();
    var scrollTop = $(window).scrollTop();
    var nHeight = Navigation.$element.height();
    var isFixed = scrollTop > (nHeight - wHeight);
    var isWindowSmallerThanSideBar = (nHeight - wHeight > 0);

    Navigation.$element.toggleClass('Navigation--fixed', isFixed);

    if (isFixed) {
      if (isWindowSmallerThanSideBar) {
        Navigation.$element.removeAttr('style');
      } else {
        Navigation.$element.css('bottom', 'auto');
      }      
    } else {
      Navigation.$element.removeAttr('style');
    }
  }

  $(window).on('resize', onResize);
  $(window).on('scroll', onResize);
  onResize();
  window.Navigation = Navigation;
});

$(function(){
  $('.Newsletter.Overlay').on('click', toggleNewsletter);
  $('.Newsletter .Modal').on('click', function(e) { e.stopPropagation(); });
  
  $('.Sharing.Overlay').on('click', toggleSharing);
  $('.Sharing .Modal').on('click', function(e) { e.stopPropagation(); });
  
  $('.Search.Overlay').on('click', toggleSearch);
  $('.Search .Modal').on('click', function(e) { e.stopPropagation(); });

  function toggleNewsletter() {
    if ($('.Newsletter.Overlay').is(':visible')) {
      $('.Newsletter.Overlay').fadeOut();
    } else {
      $('.Newsletter.Overlay').fadeIn();
    }
  }

  function toggleSharing() {
    if ($('.Sharing.Overlay').is(':visible')) {
      $('.Sharing.Overlay').fadeOut();
    } else {
      $('.Sharing.Overlay').fadeIn();
    }
  }

  function toggleSearch() {
    if ($('.Search.Overlay').is(':visible')) {
      $('.Search.Overlay').fadeOut();
    } else {
      $('.Search.Overlay').fadeIn();
    }
  }

  window.toggleNewsletter = toggleNewsletter;
  window.toggleSharing = toggleSharing;
  window.toggleSearch = toggleSearch;
});

$(function(){
  $('[data-nice-select]').niceSelect();

  $('[data-nice-select]').on('click.nice_select', function(event) {
    var $option = $(this);
    var $dropdown = $option.closest('.nice-select');
    var oldSelectedValue = $dropdown.find('.selected').data('value');
    $dropdown.find('.selected').removeClass('selected');
    $option.addClass('selected');

    var text = $option.data('display') || $option.text();
    $dropdown.find('.current').text(text);

    $dropdown.prev('select').find('option[value="' + oldSelectedValue + '"]').attr('selected',false);
    $dropdown.prev('select').find('option[value="' + $option.data('value') + '"]').attr('selected','true');
    $dropdown.prev('select').val($option.data('value')).change();
  });
});
